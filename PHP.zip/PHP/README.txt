Download and unzip the most recent version of PHP in this folder. Overwrite all.
Make sure that the php-cgi.exe file is located in exactly this folder! Don't 
store it in a subfolder because our .bat file won't be able to find it then.

php.ini should have this uncommented and set to: "cgi.force_redirect = 0"

Download can be found on the official website at https://windows.php.net/download 
At the time of writing this, most recent version was 7.4.5. Download latest from:

https://windows.php.net/downloads/releases/

PEASE MAKE SURE YOU HAVE INSTALLED MS Visual Studio Redistributables BECAUSE 
PHP WILL NOT WORK WITHOUT THESE.

https://support.microsoft.com/nl-nl/help/2977003/the-latest-supported-visual-c-downloads
